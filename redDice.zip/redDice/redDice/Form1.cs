﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace redDice
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Call built-in System.Random lives in System namespace in .Net!
            Random r = new Random();

            //Declare new data to get random value from object r.
            int iRnd = new int();//Data must be intialized before use.

            iRnd = r.Next(0, 6);//Counting randomly from 0 to 5.

            //Compare the data with each random number.
            if (iRnd == 0)
                pictureBox7.Image = pictureBox1.Image;
            else if (iRnd == 1)
                pictureBox7.Image = pictureBox2.Image;
            else if (iRnd == 2)
                pictureBox7.Image = pictureBox3.Image;
            else if (iRnd == 3)
                pictureBox7.Image = pictureBox4.Image;
            else if (iRnd == 4)
                pictureBox7.Image = pictureBox5.Image;
            else //if (iRnd == 5)
                pictureBox7.Image = pictureBox6.Image;

            iRnd = r.Next(0, 6);//Counting randomly from 0 to 5.
            if (iRnd == 0)
                pictureBox8.Image = pictureBox1.Image;
            else if (iRnd == 1)
                pictureBox8.Image = pictureBox2.Image;
            else if (iRnd == 2)
                pictureBox8.Image = pictureBox3.Image;
            else if (iRnd == 3)
                pictureBox8.Image = pictureBox4.Image;
            else if (iRnd == 4)
                pictureBox8.Image = pictureBox5.Image;
            else //if (iRnd == 5)
                pictureBox8.Image = pictureBox6.Image;
        }
        
        private void button2_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
